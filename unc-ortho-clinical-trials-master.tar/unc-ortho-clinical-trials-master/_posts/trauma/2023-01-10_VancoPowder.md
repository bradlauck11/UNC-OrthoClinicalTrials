---
layout: post
title: Vanco in open fractures
category: trauma
---

## Study Contact:  
- Bradley Lauck (bradley_lauck@med.unc.edu)


## Study Info
- IRB#: 22-1581 
- PI: Andrew Chen, MD

## Study Summary
-

##  Inclusion Criteria

- 

##  Exclusion Criteria

- 

## Study Timeline

- 

## Payment
- 

## Study Cost Coverage
- 

